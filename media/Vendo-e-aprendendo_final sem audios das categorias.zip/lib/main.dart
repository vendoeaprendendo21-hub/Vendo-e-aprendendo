import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'dart:convert';
import 'dart:async';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Ativa o modo imersivo total
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vendo e Aprendendo',
      theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.orange),
          useMaterial3: true),
      home: const CategoryScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// --- UTILITÁRIOS ---
String getGitHubUrl(String fileName, String folderPath) {
  if (fileName.isEmpty) return '';
  const String baseUrl =
      "https://raw.githubusercontent.com/vendoeaprendendo21-hub/Vendo-e-aprendendo/main/media";
  return '$baseUrl/$folderPath/$fileName';
}

// --- MODELOS DE DADOS ---
class Category {
  final String name;
  final Color color;
  final List<Item> items;
  Category({required this.name, required this.color, required this.items});

  factory Category.fromJson(Map<String, dynamic> json) {
    return Category(
      name: json['name'] ?? '',
      color: Color(
          int.parse((json['color'] ?? '#FF0000').replaceAll('#', '0xff'))),
      items:
          (json['items'] as List?)?.map((i) => Item.fromJson(i)).toList() ?? [],
    );
  }
}

class Item {
  final String nameItem;
  final String imageId, soundId, soundEnId, soundPtId;
  Item(
      {required this.nameItem,
      required this.imageId,
      required this.soundId,
      required this.soundEnId,
      required this.soundPtId});

  factory Item.fromJson(Map<String, dynamic> json) {
    return Item(
      nameItem: json['name_item'] ?? '',
      imageId: json['image_id'] ?? '',
      soundId: json['sound_id'] ?? '',
      soundEnId: json['sound_en_id'] ?? '',
      soundPtId: json['sound_pt_id'] ?? '',
    );
  }
}

// --- TELA 1: CATEGORIAS ---
class CategoryScreen extends StatefulWidget {
  const CategoryScreen({super.key});
  @override
  State<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  final String jsonUrl =
      'https://raw.githubusercontent.com/vendoeaprendendo21-hub/Vendo-e-aprendendo/main/config2.json';
  List<Category>? _categories;
  bool _isLoading = true;
  final Map<String, double> _downloadProgress = {};

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    final prefs = await SharedPreferences.getInstance();
    final cached = prefs.getString('cached_json');
    if (cached != null) {
      setState(() {
        _categories = _parseJson(cached);
        _isLoading = false;
      });
    }
    await _checkUpdate(prefs);
  }

  Future<void> _checkUpdate(SharedPreferences prefs) async {
    try {
      final connectivity = await Connectivity().checkConnectivity();
      if (connectivity.contains(ConnectivityResult.none)) return;
      final response = await http
          .get(Uri.parse(jsonUrl))
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        if (response.body != prefs.getString('cached_json')) {
          await prefs.setString('cached_json', response.body);
          if (mounted) setState(() => _categories = _parseJson(response.body));
        }
      }
    } catch (_) {
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  List<Category> _parseJson(String body) =>
      (json.decode(body) as List).map((c) => Category.fromJson(c)).toList();

  Future<void> _cacheItemAssets(Item item) async {
    try {
      await Future.wait([
        if (item.imageId.isNotEmpty)
          precacheImage(
              CachedNetworkImageProvider(getGitHubUrl(item.imageId, 'images')),
              context),
        if (item.soundPtId.isNotEmpty)
          DefaultCacheManager()
              .getSingleFile(getGitHubUrl(item.soundPtId, 'audio/pt')),
        if (item.soundEnId.isNotEmpty)
          DefaultCacheManager()
              .getSingleFile(getGitHubUrl(item.soundEnId, 'audio/en')),
        if (item.soundId.isNotEmpty)
          DefaultCacheManager()
              .getSingleFile(getGitHubUrl(item.soundId, 'audio/real')),
      ]);
    } catch (_) {}
  }

  Future<void> _downloadFullCategory(Category category) async {
    HapticFeedback.mediumImpact();
    if (_downloadProgress[category.name] == 1.0) return;
    int total = category.items.length;
    int completed = 0;
    setState(() => _downloadProgress[category.name] = 0.01);
    for (var item in category.items) {
      await _cacheItemAssets(item);
      completed++;
      if (mounted)
        setState(() => _downloadProgress[category.name] = completed / total);
    }
    setState(() => _downloadProgress[category.name] = 1.0);
    HapticFeedback.mediumImpact();
  }

  void _showDeleteConfirmation(BuildContext context) {
    HapticFeedback.vibrate();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Limpar arquivos?"),
        content: const Text("Isso removerá imagens e sons baixados."),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("CANCELAR")),
          TextButton(
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            onPressed: () async {
              HapticFeedback.heavyImpact();
              Navigator.pop(context);
              await DefaultCacheManager().emptyCache();
              setState(() => _downloadProgress.clear());
              if (mounted)
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    content: Text("Cache limpo!"),
                    backgroundColor: Colors.redAccent));
            },
            child: const Text("LIMPAR TUDO"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 90,
        title: const Text("Vendo e Aprendendo",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 26)),
        centerTitle: true,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(30))),
        actions: [
          IconButton(
            padding: const EdgeInsets.only(right: 20),
            icon: const Icon(Icons.delete_sweep_outlined,
                color: Colors.orange, size: 30),
            onPressed: () => _showDeleteConfirmation(context),
          ),
        ],
      ),
      body: _isLoading && _categories == null
          ? const Center(child: CircularProgressIndicator())
          : GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12),
              itemCount: _categories?.length ?? 0,
              itemBuilder: (context, i) {
                final cat = _categories![i];
                double progress = _downloadProgress[cat.name] ?? 0.0;
                return Card(
                  color: cat.color,
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                  child: Stack(
                    children: [
                      InkWell(
                        onTap: () {
                          HapticFeedback.lightImpact();
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) =>
                                      ItemGridScreen(category: cat)));
                        },
                        child: Center(
                            child: Text(cat.name,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold))),
                      ),
                      Positioned(
                        bottom: 8,
                        right: 8,
                        child: GestureDetector(
                          onTap: () => _downloadFullCategory(cat),
                          child: progress == 1.0
                              ? const Icon(Icons.check_circle,
                                  color: Colors.greenAccent)
                              : const Icon(Icons.download_for_offline,
                                  color: Colors.white70),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}

// --- TELA 2: GRADE DE ITENS (COM BOTÃO VOLTAR CUSTOMIZADO) ---
class ItemGridScreen extends StatelessWidget {
  final Category category;
  const ItemGridScreen({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Scaffold(
            appBar: AppBar(
              toolbarHeight: 85,
              title: Text(category.name,
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
              backgroundColor: category.color,
              automaticallyImplyLeading: false,
              centerTitle: true,
              shape: const RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.vertical(bottom: Radius.circular(25))),
            ),
            body: GridView.builder(
              padding: const EdgeInsets.all(12),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 0.85),
              itemCount: category.items.length,
              itemBuilder: (context, index) {
                final item = category.items[index];
                return GestureDetector(
                  onTap: () {
                    HapticFeedback.lightImpact();
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => ImageViewerScreen(
                                category: category, initialIndex: index)));
                  },
                  child: Card(
                    elevation: 4,
                    clipBehavior: Clip.antiAlias,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(
                            child: Hero(
                                tag: 'hero-${item.imageId}-$index',
                                child: CachedNetworkImage(
                                  imageUrl:
                                      getGitHubUrl(item.imageId, 'images'),
                                  fit: BoxFit.cover,
                                  placeholder: (context, url) => const Center(
                                      child: CircularProgressIndicator(
                                          strokeWidth: 2)),
                                  errorWidget: (context, url, error) =>
                                      Container(
                                    color: Colors.grey[200],
                                    child: const Icon(Icons.image_not_supported,
                                        color: Colors.grey, size: 40),
                                  ),
                                ))),
                        Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(item.nameItem,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold))),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          // Botão de Voltar Padronizado com BoxShadow (CORRIGIDO)
          Positioned(
            top: 20,
            left: 20,
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    offset: const Offset(1, 2),
                    blurRadius: 5.0,
                    spreadRadius: 1.0, // Opcional: aumenta a área da sombra
                  ),
                ],
              ),
              child: IconButton(
                  icon: const Icon(Icons.arrow_back_ios_new,
                      color: Colors.white, size: 35),
                  onPressed: () {
                    HapticFeedback.mediumImpact();
                    Navigator.pop(context);
                  }),
            ),
          ),
        ],
      ),
    );
  }
}

// --- TELA 3: TELA CHEIA IMERSIVA (COM BOXSHADOW) ---
class ImageViewerScreen extends StatefulWidget {
  final Category category;
  final int initialIndex;
  const ImageViewerScreen(
      {super.key, required this.category, required this.initialIndex});
  @override
  State<ImageViewerScreen> createState() => _ImageViewerScreenState();
}

class _ImageViewerScreenState extends State<ImageViewerScreen>
    with SingleTickerProviderStateMixin {
  late PageController _pageController;
  final AudioPlayer _audioPlayer = AudioPlayer();
  late int _currentIndex;
  bool _isLoadingFirst = true;
  late AnimationController _animController;
  late Animation<double> _scaleAnim;
  bool _isPt = false, _isEn = false, _isReal = false;
  int _seqId = 0;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _pageController = PageController(initialPage: widget.initialIndex);
    _animController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 400));
    _scaleAnim = Tween(begin: 1.0, end: 1.2).animate(
        CurvedAnimation(parent: _animController, curve: Curves.easeInOut));
    _loadInitialData();
  }

  Future<void> _loadInitialData() async {
    try {
      await precacheImage(
          CachedNetworkImageProvider(getGitHubUrl(
              widget.category.items[_currentIndex].imageId, 'images')),
          context);
    } catch (_) {}
    if (mounted) setState(() => _isLoadingFirst = false);
    _playFullSequence();
  }

  void _onPageChanged(int index) {
    HapticFeedback.selectionClick();
    setState(() {
      _currentIndex = index;
      _seqId++;
    });
    _playFullSequence();
  }

  Future<void> _playFullSequence() async {
    int id = ++_seqId;
    _resetVisuals();
    final item = widget.category.items[_currentIndex];
    if (await _playStep(item.soundPtId, 'audio/pt', pt: true, id: id)) {
      if (await _playStep(item.soundEnId, 'audio/en', en: true, id: id)) {
        if (item.soundId.isNotEmpty)
          await _playStep(item.soundId, 'audio/real', real: true, id: id);
      }
    }
  }

  Future<bool> _playStep(String f, String fol,
      {bool pt = false,
      bool en = false,
      bool real = false,
      required int id}) async {
    if (f.isEmpty || id != _seqId || !mounted) return false;
    setState(() {
      _isPt = pt;
      _isEn = en;
      _isReal = real;
    });
    _animController.repeat(reverse: true);
    try {
      final url = getGitHubUrl(f, fol);
      var file = await DefaultCacheManager().getFileFromCache(url);
      if (file != null)
        await _audioPlayer.play(DeviceFileSource(file.file.path));
      else
        await _audioPlayer.play(UrlSource(url));
      await _audioPlayer.onPlayerComplete.first;
    } catch (_) {}
    if (mounted) _animController.reset();
    return id == _seqId;
  }

  void _resetVisuals() {
    if (mounted)
      setState(() {
        _isPt = _isEn = _isReal = false;
      });
    _animController.reset();
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    _animController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoadingFirst)
      return const Scaffold(
          backgroundColor: Colors.black,
          body: Center(child: CircularProgressIndicator()));
    final current = widget.category.items[_currentIndex];
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(
            child: PageView.builder(
              controller: _pageController,
              itemCount: widget.category.items.length,
              onPageChanged: _onPageChanged,
              itemBuilder: (_, i) => Hero(
                tag: 'hero-${widget.category.items[i].imageId}-$i',
                child: CachedNetworkImage(
                  imageUrl:
                      getGitHubUrl(widget.category.items[i].imageId, 'images'),
                  fit: BoxFit.cover,
                  alignment: Alignment.center,
                  errorWidget: (context, url, error) => const Center(
                    child: Icon(Icons.broken_image,
                        color: Colors.white24, size: 100),
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            height: 300,
            child: Container(
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                  Colors.transparent,
                  Colors.black.withOpacity(0.9)
                ]))),
          ),
          Positioned(
            bottom: 50,
            left: 20,
            right: 20,
            child: Center(
                child: Text(current.nameItem.toUpperCase(),
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 34,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                        shadows: [
                          Shadow(blurRadius: 15, color: Colors.black)
                        ]))),
          ),
          // Botão Voltar Imersivo com BoxShadow (CORRIGIDO)
          Positioned(
              top: 20,
              left: 20,
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      offset: const Offset(1, 2),
                      blurRadius: 5.0,
                      spreadRadius: 1.0, // Opcional: aumenta a área da sombra
                    ),
                  ],
                ),
                child: IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new,
                        color: Colors.white, size: 35),
                    onPressed: () {
                      HapticFeedback.mediumImpact();
                      Navigator.pop(context);
                    }),
              )),
          Positioned(
            top: 45,
            right: 20,
            child: Row(
              children: [
                _buildActionButton(
                    "🇧🇷",
                    _isPt,
                    () => _playStep(current.soundPtId, 'audio/pt',
                        pt: true, id: ++_seqId)),
                const SizedBox(width: 15),
                _buildActionButton(
                    "🇺🇸",
                    _isEn,
                    () => _playStep(current.soundEnId, 'audio/en',
                        en: true, id: ++_seqId)),
                if (current.soundId.isNotEmpty) ...[
                  const SizedBox(width: 15),
                  _buildActionButton(
                      null,
                      _isReal,
                      () => _playStep(current.soundId, 'audio/real',
                          real: true, id: ++_seqId),
                      icon: Icons.volume_up),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton(String? label, bool anim, VoidCallback onTap,
      {IconData? icon}) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      child: ScaleTransition(
        scale: anim ? _scaleAnim : const AlwaysStoppedAnimation(1.0),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: anim ? Colors.orange : Colors.white24,
              border: Border.all(
                  color: anim ? Colors.white : Colors.white38, width: 2)),
          child: icon != null
              ? Icon(icon, color: Colors.white, size: 32)
              : Text(label!, style: const TextStyle(fontSize: 32)),
        ),
      ),
    );
  }
}
