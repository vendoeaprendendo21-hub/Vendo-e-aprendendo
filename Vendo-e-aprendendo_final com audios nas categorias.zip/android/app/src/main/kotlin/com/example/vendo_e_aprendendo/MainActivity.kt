package com.example.vendo_e_aprendendo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
